Disk-SMART-Perl
===============

Perl module for interfacing with S.M.A.R.T. on a SSD or hard drive
